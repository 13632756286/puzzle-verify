//添加自定义APL：
if (typeof jQuery !== "function") throw new Error("myquery依赖于jquery，必须先引入jquery.js");
else {
    $(function() {
        let canMove = false; //判断是否开启了移动
        let runway = $(".slider-runway"); //运行轨道
        let pop = $(".slider-button"); //按钮
        let quick = $(".verify-quick"); //验证图片
        let bar = $(".slider-bar"); //滑块颜色区域

        runway.mousedown(function(e) {
            // 只有点击运行轨道自身或者滑块的颜色区域才可以触发
            if ($(e.target).attr('class') === $(this).attr('class') || $(e.target).attr('class') === bar.attr('class')) {
                pop.css("left", e.offsetX);
                quick.css("left", e.offsetX);
                bar.css("width", e.offsetX);
            }
            canMove = true;
        });

        pop.mousedown(function(e) {
            canMove = true;
        });

        window.onmousemove = function(e) {
            if (canMove) {
                let { clientX } = e;
                let moveDistance = clientX - runway.offset().left;
                if (runway.width() - quick.width() > moveDistance && moveDistance > 0) {
                    pop.css("left", moveDistance);
                    quick.css("left", moveDistance);
                    bar.css("width", moveDistance);
                }
            }
        };

        window.onmouseup = function() {
            if (quick.position().left > 133 && quick.position().left < 137) {
                quick.position().left = 135;
                alert("验证成功");
            }
            canMove = false; //松开时关闭
        };
    })
}